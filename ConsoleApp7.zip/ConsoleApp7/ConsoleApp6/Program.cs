﻿using System;
class HelloWorld
{
    static void Main()
    {
        string message = "Hello World!!";
        for (int i = message.Length - 1; i >= 0; i--) {
            Console.WriteLine(message[i]);
        }
    }
}


       
    

